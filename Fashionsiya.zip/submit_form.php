<?php
$servername = "localhost";
$username = "your_username";
$password = "your_password";
$dbname = "your_database";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$name = $_POST['name'];
$email = $_POST['email'];
$contact_no = $_POST['contact_no'];
$message = $_POST['message'];

$stmt = $conn->prepare("INSERT INTO contact_form (name, email, contact_no, message, created_at) VALUES (?, ?, ?, ?, NOW())");
$stmt->bind_param("ssss", $name, $email, $contact_no, $message);
$stmt->execute();
$stmt->close();

$conn->close();
?>
